# YOS - YourtionOS

[![Build Status](https://travis-ci.org/yourtion/YOS.svg?branch=master)](https://travis-ci.org/yourtion/YOS)

YourtionOS 基于 (OSASK) [30dayMakeOS](https://github.com/yourtion/30dayMakeOS) 构建你自己的操作系统。

## 开发计划（功能）

- [X] 支持 Mac 开发环境
- [X] 支持 Linux 开发环境
- [X] 支持 Windows 开发环境
- [X] 源码结构更新优化
- [X] 支持中文编码
