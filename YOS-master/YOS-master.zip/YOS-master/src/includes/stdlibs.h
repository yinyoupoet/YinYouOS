int putchar(int c);
void exit(int status);
int printf(char *format, ...);
void *malloc(int size);